param([string]$GameRoot)
$ErrorActionPreference = 'Stop'

function Resolve-GameRoot {
    param([string]$RequestedRoot)
    if ($RequestedRoot) { return [IO.Path]::GetFullPath($RequestedRoot.Trim('"')).TrimEnd('\') }
    $localCandidate = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
    if (Test-Path -LiteralPath (Join-Path $localCandidate 'Dawnwalker\Binaries\Win64\Dawnwalker.exe') -PathType Leaf) { return $localCandidate }
    $entered = Read-Host 'Enter the game folder that contains the Dawnwalker folder'
    if (!$entered) { throw 'A game folder is required. Nothing was removed.' }
    return [IO.Path]::GetFullPath($entered.Trim('"')).TrimEnd('\')
}

$gamePath = Resolve-GameRoot $GameRoot
$binPath = Join-Path $gamePath 'Dawnwalker\Binaries\Win64'
$exePath = Join-Path $binPath 'Dawnwalker.exe'
$dllPath = Join-Path $binPath 'version.dll'
$modPath = Join-Path $binPath 'TrueDaywalker'
$manifestPath = Join-Path $modPath 'installation.json'
$payload = Join-Path $PSScriptRoot 'Dawnwalker\Binaries\Win64\version.dll'

if (!(Test-Path -LiteralPath $exePath -PathType Leaf)) { throw "Dawnwalker.exe was not found at $exePath" }
if (Get-Process -Name Dawnwalker -ErrorAction SilentlyContinue) { throw 'Close Dawnwalker before uninstalling.' }

if (Test-Path -LiteralPath $dllPath -PathType Leaf) {
    $currentHash = (Get-FileHash -LiteralPath $dllPath -Algorithm SHA256).Hash
    $recognized = $false
    if (Test-Path -LiteralPath $payload -PathType Leaf) {
        if ($currentHash -eq (Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash) { $recognized = $true }
    }
    if (!$recognized -and (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        try {
            $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
            if ($manifest.Mod -eq 'TrueDaywalker' -and $manifest.DllSHA256 -eq $currentHash) { $recognized = $true }
        } catch { }
    }
    if (!$recognized) { throw 'The installed version.dll is not recognized as True Daywalker. It has been left untouched.' }
    Remove-Item -LiteralPath $dllPath -Force
}

if (Test-Path -LiteralPath $modPath) { Remove-Item -LiteralPath $modPath -Recurse -Force }
Write-Host ''
Write-Host 'True Daywalker removed.' -ForegroundColor Green
Write-Host 'Save files and installer backups were not removed.'
