param([string]$GameRoot)
$ErrorActionPreference = 'Stop'
if (!$GameRoot) { $GameRoot = Read-Host 'Enter the game folder that contains the Dawnwalker folder' }
if (!$GameRoot) { throw 'A game folder is required.' }
$gamePath=[IO.Path]::GetFullPath($GameRoot.Trim('"')).TrimEnd('\')
$exe=Join-Path $gamePath 'Dawnwalker\Binaries\Win64\Dawnwalker.exe'
if (!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw "Dawnwalker.exe was not found at $exe" }
$bytes=[IO.File]::ReadAllBytes($exe)
function U16([int]$at) { [BitConverter]::ToUInt16($bytes,$at) }
function U32([int]$at) { [BitConverter]::ToUInt32($bytes,$at) }
function U64([int]$at) { [BitConverter]::ToUInt64($bytes,$at) }
$nt=[BitConverter]::ToInt32($bytes,60)
$optional=$nt+24
$count=U16 ($nt+6)
$table=$nt+24+(U16 ($nt+20))
$vi=(Get-Item -LiteralPath $exe).VersionInfo
$lines=[Collections.Generic.List[string]]::new()
$lines.Add('True Daywalker compatibility report')
$lines.Add('Generated: '+(Get-Date).ToString('o'))
$lines.Add('Path: '+$exe)
$lines.Add('Size: '+$bytes.Length)
$lines.Add('SHA256: '+(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash)
$lines.Add('FileVersion: '+$vi.FileVersion)
$lines.Add('ProductVersion: '+$vi.ProductVersion)
$lines.Add(('Machine: 0x{0:X4}' -f (U16 ($nt+4))))
$lines.Add('Sections: '+$count)
$lines.Add(('OptionalMagic: 0x{0:X4}' -f (U16 $optional)))
$lines.Add(('ImageBase: 0x{0:X}' -f (U64 ($optional+24))))
$lines.Add(('EntryPoint: 0x{0:X}' -f (U32 ($optional+16))))
$lines.Add(('SectionAlignment: 0x{0:X}' -f (U32 ($optional+32))))
$lines.Add(('FileAlignment: 0x{0:X}' -f (U32 ($optional+36))))
$lines.Add(('SizeOfImage: 0x{0:X}' -f (U32 ($optional+56))))
$lines.Add(('SizeOfHeaders: 0x{0:X}' -f (U32 ($optional+60))))
$lines.Add('')
$sha=[Security.Cryptography.SHA256]::Create()
try {
  for($i=0;$i -lt $count;$i++) {
    $at=$table+$i*40
    $name=[Text.Encoding]::ASCII.GetString($bytes,$at,8).TrimEnd([char]0)
    $vs=U32 ($at+8); $rva=U32 ($at+12); $rawSize=U32 ($at+16); $raw=U32 ($at+20); $ch=U32 ($at+36)
    $hash='OUTSIDE_FILE'
    if([uint64]$raw+$rawSize -le $bytes.Length) {
      $hash=([BitConverter]::ToString($sha.ComputeHash($bytes,[int]$raw,[int]$rawSize))).Replace('-','').ToLowerInvariant()
    }
    $lines.Add(('{0}: RVA=0x{1:X} VS=0x{2:X} RAW=0x{3:X} RAW_SIZE=0x{4:X} CHAR=0x{5:X8} SHA256={6}' -f $name,$rva,$vs,$raw,$rawSize,$ch,$hash))
  }
} finally { $sha.Dispose() }
$out=Join-Path $PSScriptRoot 'TrueDaywalker-compatibility-report.txt'
[IO.File]::WriteAllLines($out,$lines,[Text.Encoding]::UTF8)
Write-Host ''
Write-Host "Saved compatibility report: $out" -ForegroundColor Green
Write-Host 'Attach or paste this report with your TrueDaywalker.log if the compatibility hotfix still does not load.'
