TRUE DAYWALKER
Version 0.4.5 Beta Compatibility Hotfix

INSTALL
=======
1. Close The Blood of Dawnwalker.
2. Drag the Dawnwalker folder from this archive into the game's main folder.
3. Allow Windows to merge the folders.
4. Start the game and load a save.

That's it. No installer, no PowerShell, no game-path prompt, and no external mod
framework is required.

IMPORTANT: NATIVE LOADER CONFLICTS
==================================
True Daywalker uses:

  Dawnwalker\Binaries\Win64\version.dll

If that file already exists BEFORE you install True Daywalker and it belongs to
another native mod/loader, do not overwrite it blindly. Two mods trying to own
the same version.dll proxy can conflict.

UPDATING TRUE DAYWALKER
=======================
Drag the Dawnwalker folder into the same game folder again and replace
version.dll when prompted.

If you have customized TrueDaywalker.ini, keep your existing INI instead of
overwriting it with the packaged default.

FILES INSTALLED
===============
  Dawnwalker\Binaries\Win64\version.dll
  Dawnwalker\Binaries\Win64\TrueDaywalker\TrueDaywalker.ini

The README and licenses are stored beside the configuration so the archive root
stays clean.

CONFIGURATION
=============
Edit TrueDaywalker.ini with Notepad, then restart the game.

Public defaults:
  Enabled=1
  RespectForcedHuman=0
  UnionConsumables=1
  Appearance=Vampire
  UnionHealing=1
  Diagnostics=0
  UnionAbilityQuickslots=1
  UnionHealthBonuses=1
  Unarmed=Cycle
  Movement=Wolf

Appearance:
  Vampire = vampire appearance day and night
  Natural = native day/night appearance

Unarmed:
  Cycle = Sword -> Claws -> Fists
  Claws = fixed claws
  Fists = fixed fists

Movement:
  Wolf = stable public default
  Haste = experimental / may fall back to Wolf
  TapHold = experimental tap Haste / hold Wolf behavior

WHAT IT DOES
============
True Daywalker keeps Coen on one persistent human/vampire hybrid gameplay
ruleset instead of forcing those systems to alternate with the world clock.

Current features include Witchcraft while vampiric, vampire powers during the
day, daytime feeding through Focus Mode, segmented Blood as the active health
resource, human healing/bonuses integrated into Blood, cross-form consumables,
Day/Night quick-slot union, Sword/Claws/Fists cycling, configurable appearance,
Wolf traversal, and restored Compel/Astral Communion behavior in hybrid form.

KNOWN LIMITATIONS
=================
- Wolf is the stable traversal option. Haste remains experimental.
- An extra sword flourish can occur when cycling Fists -> Sword.
- Native mods that also own version.dll or hook the same gameplay systems may
  conflict.

0.4.5 COMPATIBILITY HOTFIX
==========================
This build includes runtime signature checks for the native hooks. If required
hook signatures do not match the running game build, the affected hooks fail
closed rather than blindly patching unknown code.

UNINSTALL
=========
1. Close the game.
2. Delete Dawnwalker\Binaries\Win64\version.dll ONLY if it is the True Daywalker
   loader.
3. Delete Dawnwalker\Binaries\Win64\TrueDaywalker\ if you also want to remove
   its configuration, README and licenses.

Saves are not installed, removed or edited by these file operations.

SOURCE / SECURITY
=================
Source, build information and security-review material:
https://github.com/Enigma-Amygdala/True-Daywalker

True Daywalker uses an in-process version.dll proxy and native detours. The
packaged implementation contains no intended network client, telemetry,
downloader, remote-process injection, driver or persistence mechanism. Native
runtime hooks can trigger heuristic antivirus detections. Do not add antivirus
exclusions just to run the mod.
