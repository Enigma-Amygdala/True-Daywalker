TRUE DAYWALKER
Version 0.4.5 Beta Compatibility Hotfix
Supported native profile: CL-258504 / patch 2

============================================================
IMPORTANT UPDATE
============================================================

0.4.4 fixes a progression-blocking hybrid-form bug that could prevent
Astral Communion at haunted sites and Compel interactions with eligible
corpses. Updating from 0.3.0 is strongly recommended.

The fix is narrowly scoped: it removes only the Player.IsVampire activation
blocker for Astral Communion and Compel when the game checks those abilities
for Coen. Native quest, target, learned-ability, range, combat, cost and
completion requirements remain intact.

Initial daytime testing confirmed both Astral Communion and Compel working.

============================================================
WHAT TRUE DAYWALKER DOES
============================================================

True Daywalker makes Coen one persistent human/vampire hybrid ruleset rather
than forcing the gameplay systems to alternate with the world clock.

Current features include:
- Witchcraft while functioning as a vampire.
- Vampire powers during the day.
- Daytime feeding through Focus Mode.
- Native segmented Blood retained as the active resource/health model.
- Human healing and regeneration integrated into the Blood system.
- Human Health/Restoration percentage bonuses integrated into Blood.
- Human and vampire consumables available when their normal requirements pass.
- Learned Witchcraft and vampire powers assignable to either Day or Night
  ability quick-slot bank.
- Sword -> Claws -> Fists -> Sword weapon cycling through the mapped weapon
  action.
- Fixed Claws or Fists modes available through configuration.
- Always-vampire or natural day/night appearance without changing the hybrid
  gameplay rules.
- Wolf traversal remains available in hybrid mode.
- Compel and Astral Communion restored in hybrid form.

No external mod framework is required.

============================================================
INSTALLATION - RECOMMENDED
============================================================

1. Close The Blood of Dawnwalker.
2. Extract the complete archive to a normal folder.
3. Double-click Install.cmd.
4. Enter the main game folder that CONTAINS the Dawnwalker folder if prompted.
5. Start the game and load a save.

The installer:
- validates the supported native game profile before installing;
- refuses to overwrite an unrecognized version.dll;
- verifies the installed True Daywalker DLL after copying;
- preserves existing True Daywalker settings;
- creates a rollback backup under:
  %LOCALAPPDATA%\TrueDaywalker\Backups\
- also backs up the current Dawnwalker save folder before the update.

No administrator rights should be needed when the game folder is writable.

============================================================
MANUAL INSTALLATION
============================================================

Close the game, then merge the included Dawnwalker folder into the game's
main folder.

After installation these paths should exist:

<Game Folder>\Dawnwalker\Binaries\Win64\version.dll
<Game Folder>\Dawnwalker\Binaries\Win64\TrueDaywalker\TrueDaywalker.ini

IMPORTANT: If version.dll already exists and is not from True Daywalker, do
not blindly replace it. Another native mod may own that proxy loader.

============================================================
CONFIGURATION
============================================================

Run:
Dawnwalker\Binaries\Win64\TrueDaywalker\Configure.cmd

You can configure:
- Appearance: Always Vampire or Natural day/night appearance.
- Unarmed mode: Sword/Claws/Fists cycle, fixed Claws, or fixed Fists.
- Movement: Wolf, Haste, or experimental Tap/Hold behavior.

Restart Dawnwalker after changing settings.

Public-release defaults:
Enabled=1
RespectForcedHuman=0
UnionConsumables=1
Appearance=Vampire
UnionHealing=1
Diagnostics=0
UnionAbilityQuickslots=1
UnionHealthBonuses=1
Unarmed=Cycle
Movement=Wolf

============================================================
KNOWN LIMITATIONS
============================================================

1. HASTE / MERCURIAL FERVOR

Wolf Form is the stable traversal option in this build. Haste is not yet
reliably activatable through the hybrid traversal path. The TapHold option is
experimental and is not the public default.

2. WEAPON-CYCLE FLOURISH

An extra sword flourish can occur when cycling from Fists back to Sword.
The stance change still completes.

3. COMPATIBILITY

0.4.4 no longer relies only on one whole-file executable hash. The installer
checks a CL-258504 native compatibility profile: PE layout, native code/data
sections and runtime entry signatures. Resource/signing/timestamp-only changes
can therefore remain compatible, while unknown native-code changes still fail
closed.

Other native mods that also own version.dll or hook the same gameplay systems
may conflict.

============================================================
BUG REPORTING
============================================================

If something breaks, include:
- True Daywalker version.
- Whether it was day or night.
- The ability, item, interaction or stance involved.
- The exact target/site/quest when relevant.
- Whether reloading the same save reproduces it.
- Other native gameplay mods installed.

For detailed logging, close the game and set Diagnostics=1 in
TrueDaywalker.ini, then restart. Do not post personal save files publicly.

============================================================
UNINSTALLATION
============================================================

Close the game and run Uninstall.cmd from the extracted archive.

The uninstaller removes version.dll only when it can identify it as the
installed True Daywalker loader. Unknown loaders are left untouched. Saves are
not removed or edited by the uninstaller.

============================================================
SOURCE / SECURITY
============================================================

Source, build information, hashes and security-review material:
https://github.com/Enigma-Amygdala/True-Daywalker

True Daywalker uses an in-process version.dll proxy and native detours. The
packaged implementation contains no intended network client, telemetry,
downloader, remote-process injection, driver or persistence mechanism.
Native runtime hooks can trigger heuristic antivirus detections. Keep Windows
Security enabled; do not add exclusions just to run the mod.

See LICENSE.txt for the True Daywalker license and licenses\MinHook.txt for the
third-party MinHook license.
