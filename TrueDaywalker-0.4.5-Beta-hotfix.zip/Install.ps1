param(
    [string]$GameRoot,
    [string]$SaveRoot = (Join-Path $env:LOCALAPPDATA 'Dawnwalker\Saved\SaveGames')
)
$ErrorActionPreference = 'Stop'
if (!$GameRoot) { $GameRoot = Read-Host 'Enter the game folder that contains the Dawnwalker folder' }
if (!$GameRoot) { throw 'A game folder is required. Nothing was installed.' }
$gamePath = [IO.Path]::GetFullPath($GameRoot.Trim('"')).TrimEnd('\')
$binPath = Join-Path $gamePath 'Dawnwalker\Binaries\Win64'
$exePath = Join-Path $binPath 'Dawnwalker.exe'
$dllPath = Join-Path $binPath 'version.dll'
$modPath = Join-Path $binPath 'TrueDaywalker'
$payloadRoot = Join-Path $PSScriptRoot 'Dawnwalker\Binaries\Win64'
$payload = Join-Path $payloadRoot 'version.dll'
$expectedExe = 'E565BD97FBA398ECB1CA79CA2AA2CC2E5D43156A0937D7E202E73B3B85ED5086'
if (!(Test-Path -LiteralPath $exePath -PathType Leaf)) { throw "Dawnwalker.exe was not found at $exePath" }
if (Get-Process -Name Dawnwalker -ErrorAction SilentlyContinue) { throw 'Close Dawnwalker before installing.' }
. (Join-Path $PSScriptRoot 'Test-GameCompatibility.ps1')
$profile = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'compatibility-profile.json') -Raw | ConvertFrom-Json
$compatibility = Test-TrueDaywalkerImage -Image ([IO.File]::ReadAllBytes($exePath)) -Profile $profile
if (!$compatibility.Compatible) {
    Write-Warning "Strict native image profile did not match: $($compatibility.Reason)"
    Write-Warning '0.4.5 compatibility mode will continue installation, but the DLL still verifies its runtime hook signatures before installing any hooks. If those signatures do not match, the mod fails closed and the game remains unpatched.'
} else {
    Write-Host "Strict native profile verified: $($compatibility.Reason)" -ForegroundColor Green
}
$expectedExe = (Get-FileHash -LiteralPath $exePath -Algorithm SHA256).Hash
if (!(Test-Path -LiteralPath $payload -PathType Leaf)) { throw 'The archive is incomplete: version.dll is missing.' }
$payloadHash = (Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash
$knownHashes = @('D347702882DD82B48BBC98DA743F91BDFE2021037233C55B4333866FC42EE88B','70451D2D8AFA63B713643C71CB0F0BD100FAC18F343DCFFA7E15F828B816D8C3','F53B7B7799070F047EDD096DA9CC34E286C1513E856E2B0B9D63B498F64FF709','25CEDCE56957751BF4C366EBA8780C208799AE7FECCD1C590CE2F1DDCFE5208D','C521990E5B8E69BAB2178DDC5DBCD077211E908E87557C35A370D2B42C316237','00ABF4DD6343D9C858594EDD1F39FDAB9B65055440D7838E0A426F106CCF2367',$payloadHash)
$manifestPath = Join-Path $modPath 'installation.json'
if (Test-Path -LiteralPath $dllPath) {
    $currentHash = (Get-FileHash -LiteralPath $dllPath -Algorithm SHA256).Hash
    $recognized = $knownHashes -contains $currentHash
    if (Test-Path -LiteralPath $manifestPath) {
        $previous = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
        if ($previous.Mod -eq 'TrueDaywalker' -and $previous.DllSHA256 -eq $currentHash) { $recognized=$true }
    }
    if (!$recognized) { throw 'An unrecognized version.dll is already installed. It has been left untouched; resolve the loader conflict first.' }
}
$settings = Join-Path $modPath 'TrueDaywalker.ini'
$settingsSource = if (Test-Path -LiteralPath $settings) { $settings } else { Join-Path $payloadRoot 'TrueDaywalker\TrueDaywalker.ini' }
$lines = [Collections.Generic.List[string]]::new()
$lines.AddRange([IO.File]::ReadAllLines($settingsSource))
$section = -1; $end = $lines.Count
for ($i=0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\s*\[TrueDaywalker\]\s*$') { $section=$i; continue }
    if ($section -ge 0 -and $lines[$i] -match '^\s*\[') { $end=$i; break }
}
if ($section -lt 0) { throw 'The existing configuration has no [TrueDaywalker] section. Restore its backup or the supplied default configuration.' }
foreach ($entry in @('Appearance=Vampire','UnionHealing=1','UnionAbilityQuickslots=1','UnionHealthBonuses=1','Unarmed=Cycle','Movement=Wolf')) {
    $name = $entry.Split('=')[0]
    $present = $false
    for ($i=$section+1; $i -lt $end; $i++) { if ($lines[$i] -match ('^\s*'+[regex]::Escape($name)+'\s*=')) { $present=$true; break } }
    if (!$present) { $lines.Insert($end,$entry); $end++ }
}

$backupRoot = Join-Path $env:LOCALAPPDATA 'TrueDaywalker\Backups'
New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
$backupPath = Join-Path $backupRoot (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
if (Test-Path -LiteralPath $SaveRoot) { Copy-Item -LiteralPath $SaveRoot -Destination (Join-Path $backupPath 'SaveGames') -Recurse }
if (Test-Path -LiteralPath $dllPath) { Copy-Item -LiteralPath $dllPath -Destination (Join-Path $backupPath 'previous-version.dll') }
if (Test-Path -LiteralPath $modPath) { Copy-Item -LiteralPath $modPath -Destination (Join-Path $backupPath 'previous-settings') -Recurse }
if (Get-Process -Name Dawnwalker -ErrorAction SilentlyContinue) { throw 'Dawnwalker was reopened during backup. Close it and run the installer again.' }
New-Item -ItemType Directory -Path $modPath -Force | Out-Null
Copy-Item -LiteralPath $payload -Destination $dllPath -Force
if ((Get-FileHash -LiteralPath $dllPath -Algorithm SHA256).Hash -ne $payloadHash) { throw "Installed DLL verification failed. The previous installation is backed up at $backupPath" }
[IO.File]::WriteAllLines($settings,$lines,[Text.Encoding]::Unicode)
foreach ($file in @('SelectAppearance.ps1','SelectAppearance.cmd','Configure.ps1','Configure.cmd')) { Copy-Item -LiteralPath (Join-Path $payloadRoot "TrueDaywalker\$file") -Destination (Join-Path $modPath $file) -Force }
[ordered]@{
    NativeProfile=$profile.profile; Mod='TrueDaywalker'; Version='0.4.5-beta-compat'; InstalledAt=(Get-Date).ToString('o');
    GameRoot=$gamePath; ExeSHA256=$expectedExe; DllSHA256=$payloadHash; BackupPath=$backupPath
} | ConvertTo-Json | Set-Content -LiteralPath $manifestPath -Encoding UTF8
Write-Host 'True Daywalker 0.4.5 Beta Compatibility Hotfix installed.' -ForegroundColor Green
Write-Host "Backup: $backupPath"
Write-Host "Settings selector: $(Join-Path $modPath 'Configure.cmd')"
Write-Host 'Start Dawnwalker and load a save. The game clock remains under native control.'
