@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Configure.ps1"
pause
